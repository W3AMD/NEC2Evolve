#ifndef NEC_GLOBALS_H
#define NEC_GLOBALS_H


#endif
