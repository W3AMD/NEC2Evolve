#ifndef NEC_GLOBALS
#define NEC_GLOBALS
// use vector to store original center positions since these
// get overwritten in the x,y,z variables
std::vector<nec_float>XCenterSeg, YCenterSeg, ZCenterSeg;
#endif
